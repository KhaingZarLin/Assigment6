# Assignment_5
PADC-9-Assignment-5 with HttpUrlConnection
