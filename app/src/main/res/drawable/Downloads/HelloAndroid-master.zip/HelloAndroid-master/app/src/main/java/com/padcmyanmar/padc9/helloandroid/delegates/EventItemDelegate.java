package com.padcmyanmar.padc9.helloandroid.delegates;

/**
 * Created by Ye Pyae Sone Tun
 * on 2019-08-10.
 */

public interface EventItemDelegate {
    void onTapEventItem();
}
