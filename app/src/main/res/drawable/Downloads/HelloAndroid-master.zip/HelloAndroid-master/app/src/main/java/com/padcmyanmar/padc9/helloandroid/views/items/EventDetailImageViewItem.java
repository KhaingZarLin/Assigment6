package com.padcmyanmar.padc9.helloandroid.views.items;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * Created by Ye Pyae Sone Tun
 * on 2019-08-11.
 */

public class EventDetailImageViewItem extends FrameLayout {
    public EventDetailImageViewItem(Context context) {
        super(context);
    }

    public EventDetailImageViewItem(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EventDetailImageViewItem(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
